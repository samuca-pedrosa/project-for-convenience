"""
Camada de apresentacao: interface grafica em Tkinter.

Esta e' a interface principal (e unica) da aplicacao. Ela conversa com a
mesma camada de negocio (src/negocio) que ja existia, entao todas as regras
de validacao, o calculo automatico do total da venda e a baixa de estoque
continuam funcionando exatamente como antes -- so a "porta de entrada" mudou
de uma API HTTP para uma janela grafica.

Estrutura desta tela:
- uma aba "Produtos" com formulario + lista (CRUD completo);
- uma aba "Clientes" com formulario + lista (CRUD completo);
- uma aba "Vendas" com montagem de carrinho, finalizacao de venda (que baixa
  o estoque automaticamente) e uma lista das vendas ja registradas.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk
from typing import Optional

import mysql.connector

from src.negocio.cliente_service import ClienteService
from src.negocio.produto_service import ProdutoService
from src.negocio.venda_service import VendaService

# ---------------------------------------------------------------------------
# Paleta de cores e fontes usadas em toda a interface
# ---------------------------------------------------------------------------
COR_FUNDO = "#f3f5f9"
COR_BARRA = "#1f2937"
COR_BARRA_TEXTO = "#f9fafb"
COR_BARRA_SUBTEXTO = "#9ca3af"
COR_ACCENT = "#2563eb"
COR_ACCENT_HOVER = "#1d4ed8"
COR_PERIGO = "#dc2626"
COR_PERIGO_HOVER = "#b91c1c"
COR_SECUNDARIO = "#e5e7eb"
COR_SECUNDARIO_HOVER = "#d1d5db"
COR_TEXTO = "#111827"
COR_TEXTO_SUAVE = "#6b7280"
COR_CARD = "#ffffff"
COR_BORDA = "#e2e5eb"

FONTE_BASE = ("Segoe UI", 10)
FONTE_TITULO = ("Segoe UI", 17, "bold")
FONTE_SUBTITULO = ("Segoe UI", 10)
FONTE_SECAO = ("Segoe UI", 11, "bold")
FONTE_BOTAO = ("Segoe UI", 9, "bold")
FONTE_RODAPE = ("Segoe UI", 8)


# ---------------------------------------------------------------------------
# Helpers de botoes coloridos (tk.Button simples, para ter controle total
# sobre cor de fundo em qualquer sistema operacional)
# ---------------------------------------------------------------------------
def _criar_botao(master, texto, comando, bg, fg, hover) -> tk.Button:
    botao = tk.Button(
        master,
        text=texto,
        command=comando,
        bg=bg,
        fg=fg,
        activebackground=hover,
        activeforeground=fg,
        font=FONTE_BOTAO,
        relief="flat",
        bd=0,
        padx=14,
        pady=7,
        cursor="hand2",
    )
    return botao


def botao_primario(master, texto, comando) -> tk.Button:
    return _criar_botao(master, texto, comando, COR_ACCENT, "white", COR_ACCENT_HOVER)


def botao_perigo(master, texto, comando) -> tk.Button:
    return _criar_botao(master, texto, comando, COR_PERIGO, "white", COR_PERIGO_HOVER)


def botao_secundario(master, texto, comando) -> tk.Button:
    return _criar_botao(master, texto, comando, COR_SECUNDARIO, COR_TEXTO, COR_SECUNDARIO_HOVER)


def _tratar_erro_servico(erro: Exception, contexto_integridade: str = "") -> None:
    """Mostra uma messagebox amigavel para os tipos de erro mais comuns."""
    if isinstance(erro, ValueError):
        messagebox.showerror("Dados invalidos", str(erro))
    elif isinstance(erro, mysql.connector.Error):
        detalhe = str(erro)
        if contexto_integridade and ("1451" in detalhe or "foreign key" in detalhe.lower()):
            messagebox.showerror("Nao foi possivel concluir", contexto_integridade + "\n\nDetalhes: " + detalhe)
        elif "1062" in detalhe or "duplicate" in detalhe.lower():
            messagebox.showerror("Registro duplicado", "Ja existe um registro com esse valor unico (ex.: CPF).\n\nDetalhes: " + detalhe)
        else:
            messagebox.showerror("Erro de banco de dados", detalhe)
    else:
        messagebox.showerror("Erro inesperado", str(erro))


# ---------------------------------------------------------------------------
# Aba de Produtos
# ---------------------------------------------------------------------------
class AbaProdutos(tk.Frame):
    def __init__(self, master: tk.Widget, servico: ProdutoService) -> None:
        super().__init__(master, bg=COR_FUNDO)
        self.servico = servico
        self.id_selecionado: Optional[int] = None
        self._todos: list = []
        self._montar_layout()
        self.atualizar_lista()

    def _montar_layout(self) -> None:
        painel = tk.Frame(self, bg=COR_FUNDO)
        painel.pack(fill="both", expand=True, padx=6, pady=6)
        painel.columnconfigure(1, weight=1)
        painel.rowconfigure(0, weight=1)

        card = tk.Frame(painel, bg=COR_CARD, highlightbackground=COR_BORDA, highlightthickness=1)
        card.grid(row=0, column=0, sticky="ns", padx=(0, 12))

        tk.Label(card, text="Cadastro de produto", bg=COR_CARD, fg=COR_TEXTO, font=FONTE_SECAO).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=18, pady=(18, 4)
        )
        tk.Label(
            card, text="Clique em uma linha da lista para editar ou remover.",
            bg=COR_CARD, fg=COR_TEXTO_SUAVE, font=FONTE_RODAPE,
        ).grid(row=1, column=0, columnspan=2, sticky="w", padx=18, pady=(0, 12))

        self.var_nome = tk.StringVar()
        self.var_categoria = tk.StringVar()
        self.var_preco = tk.StringVar()
        self.var_estoque = tk.StringVar()

        self._campo(card, 2, "Nome", self.var_nome)
        self._campo(card, 3, "Categoria", self.var_categoria)
        self._campo(card, 4, "Preco (R$)", self.var_preco)
        self._campo(card, 5, "Estoque", self.var_estoque)

        botoes = tk.Frame(card, bg=COR_CARD)
        botoes.grid(row=6, column=0, columnspan=2, sticky="ew", padx=18, pady=(14, 20))
        botao_primario(botoes, "Salvar", self._salvar).pack(side="left", padx=(0, 6))
        botao_secundario(botoes, "Novo", self._limpar).pack(side="left", padx=(0, 6))
        botao_perigo(botoes, "Remover", self._remover).pack(side="left")

        direita = tk.Frame(painel, bg=COR_FUNDO)
        direita.grid(row=0, column=1, sticky="nsew")
        direita.rowconfigure(1, weight=1)
        direita.columnconfigure(0, weight=1)

        topo = tk.Frame(direita, bg=COR_FUNDO)
        topo.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        tk.Label(topo, text="Produtos cadastrados", bg=COR_FUNDO, fg=COR_TEXTO, font=FONTE_SECAO).pack(side="left")
        tk.Label(topo, text="Filtrar:", bg=COR_FUNDO, fg=COR_TEXTO_SUAVE).pack(side="left", padx=(18, 4))
        self.var_filtro = tk.StringVar()
        self.var_filtro.trace_add("write", lambda *_: self._filtrar())
        ttk.Entry(topo, textvariable=self.var_filtro, width=24).pack(side="left")
        botao_secundario(topo, "Atualizar lista", self.atualizar_lista).pack(side="right")

        colunas = ("id", "nome", "categoria", "preco", "estoque")
        self.tabela = ttk.Treeview(direita, columns=colunas, show="headings", selectmode="browse")
        titulos = {"id": "ID", "nome": "Nome", "categoria": "Categoria", "preco": "Preco (R$)", "estoque": "Estoque"}
        larguras = {"id": 55, "nome": 260, "categoria": 140, "preco": 110, "estoque": 90}
        for col in colunas:
            self.tabela.heading(col, text=titulos[col])
            self.tabela.column(col, width=larguras[col], anchor="w" if col == "nome" else "center")
        self.tabela.grid(row=1, column=0, sticky="nsew")
        barra = ttk.Scrollbar(direita, orient="vertical", command=self.tabela.yview)
        self.tabela.configure(yscrollcommand=barra.set)
        barra.grid(row=1, column=1, sticky="ns")
        self.tabela.bind("<<TreeviewSelect>>", self._selecionar)

    def _campo(self, card, linha, rotulo, variavel) -> ttk.Entry:
        tk.Label(card, text=rotulo, bg=COR_CARD, fg=COR_TEXTO_SUAVE, font=FONTE_BASE).grid(
            row=linha, column=0, sticky="w", padx=(18, 10), pady=6
        )
        entrada = ttk.Entry(card, textvariable=variavel, width=26)
        entrada.grid(row=linha, column=1, sticky="ew", padx=(0, 18), pady=6)
        return entrada

    def _limpar(self) -> None:
        self.id_selecionado = None
        self.var_nome.set("")
        self.var_categoria.set("")
        self.var_preco.set("")
        self.var_estoque.set("")
        for item in self.tabela.selection():
            self.tabela.selection_remove(item)

    def _selecionar(self, event=None) -> None:
        selecionado = self.tabela.selection()
        if not selecionado:
            return
        valores = self.tabela.item(selecionado[0], "values")
        self.id_selecionado = int(valores[0])
        self.var_nome.set(valores[1])
        self.var_categoria.set(valores[2])
        self.var_preco.set(valores[3])
        self.var_estoque.set(valores[4])

    def _salvar(self) -> None:
        try:
            preco = float(self.var_preco.get().strip().replace(",", "."))
            estoque = int(self.var_estoque.get().strip())
        except ValueError:
            messagebox.showerror("Dados invalidos", "Preco deve ser um numero (ex: 9.90) e estoque um numero inteiro.")
            return

        try:
            if self.id_selecionado is None:
                produto = self.servico.cadastrar_produto(self.var_nome.get(), self.var_categoria.get(), preco, estoque)
                messagebox.showinfo("Sucesso", f"Produto '{produto.nome}' cadastrado com o ID {produto.id}.")
            else:
                ok = self.servico.atualizar_produto(
                    self.id_selecionado, self.var_nome.get(), self.var_categoria.get(), preco, estoque
                )
                if ok:
                    messagebox.showinfo("Sucesso", "Produto atualizado com sucesso.")
                else:
                    messagebox.showwarning("Aviso", "Nenhum produto foi atualizado. Verifique o ID.")
        except Exception as erro:
            _tratar_erro_servico(erro)
            return

        self._limpar()
        self.atualizar_lista()

    def _remover(self) -> None:
        if self.id_selecionado is None:
            messagebox.showwarning("Aviso", "Selecione um produto na lista para remover.")
            return
        if not messagebox.askyesno("Confirmar remocao", "Tem certeza que deseja remover este produto?"):
            return
        try:
            ok = self.servico.remover_produto(self.id_selecionado)
            if ok:
                messagebox.showinfo("Sucesso", "Produto removido com sucesso.")
            else:
                messagebox.showwarning("Aviso", "Nenhum produto foi removido.")
        except Exception as erro:
            _tratar_erro_servico(
                erro,
                contexto_integridade="Este produto nao pode ser removido porque ja esta associado a uma venda registrada.",
            )
            return
        self._limpar()
        self.atualizar_lista()

    def atualizar_lista(self) -> None:
        self._todos = self.servico.listar_produtos()
        self._preencher(self._todos)

    def _filtrar(self) -> None:
        termo = self.var_filtro.get().strip().lower()
        if not termo:
            self._preencher(self._todos)
            return
        filtrados = [p for p in self._todos if termo in p.nome.lower() or termo in p.categoria.lower()]
        self._preencher(filtrados)

    def _preencher(self, produtos) -> None:
        self.tabela.delete(*self.tabela.get_children())
        for p in produtos:
            self.tabela.insert("", "end", values=(p.id, p.nome, p.categoria, f"{p.preco:.2f}", p.estoque))


# ---------------------------------------------------------------------------
# Aba de Clientes
# ---------------------------------------------------------------------------
class AbaClientes(tk.Frame):
    def __init__(self, master: tk.Widget, servico: ClienteService) -> None:
        super().__init__(master, bg=COR_FUNDO)
        self.servico = servico
        self.id_selecionado: Optional[int] = None
        self._todos: list = []
        self._montar_layout()
        self.atualizar_lista()

    def _montar_layout(self) -> None:
        painel = tk.Frame(self, bg=COR_FUNDO)
        painel.pack(fill="both", expand=True, padx=6, pady=6)
        painel.columnconfigure(1, weight=1)
        painel.rowconfigure(0, weight=1)

        card = tk.Frame(painel, bg=COR_CARD, highlightbackground=COR_BORDA, highlightthickness=1)
        card.grid(row=0, column=0, sticky="ns", padx=(0, 12))

        tk.Label(card, text="Cadastro de cliente", bg=COR_CARD, fg=COR_TEXTO, font=FONTE_SECAO).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=18, pady=(18, 4)
        )
        tk.Label(
            card, text="CPF pode ser digitado com ou sem mascara.",
            bg=COR_CARD, fg=COR_TEXTO_SUAVE, font=FONTE_RODAPE,
        ).grid(row=1, column=0, columnspan=2, sticky="w", padx=18, pady=(0, 12))

        self.var_nome = tk.StringVar()
        self.var_cpf = tk.StringVar()
        self.var_telefone = tk.StringVar()
        self.var_email = tk.StringVar()

        self._campo(card, 2, "Nome", self.var_nome)
        self._campo(card, 3, "CPF", self.var_cpf)
        self._campo(card, 4, "Telefone (opcional)", self.var_telefone)
        self._campo(card, 5, "Email (opcional)", self.var_email)

        botoes = tk.Frame(card, bg=COR_CARD)
        botoes.grid(row=6, column=0, columnspan=2, sticky="ew", padx=18, pady=(14, 20))
        botao_primario(botoes, "Salvar", self._salvar).pack(side="left", padx=(0, 6))
        botao_secundario(botoes, "Novo", self._limpar).pack(side="left", padx=(0, 6))
        botao_perigo(botoes, "Remover", self._remover).pack(side="left")

        direita = tk.Frame(painel, bg=COR_FUNDO)
        direita.grid(row=0, column=1, sticky="nsew")
        direita.rowconfigure(1, weight=1)
        direita.columnconfigure(0, weight=1)

        topo = tk.Frame(direita, bg=COR_FUNDO)
        topo.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        tk.Label(topo, text="Clientes cadastrados", bg=COR_FUNDO, fg=COR_TEXTO, font=FONTE_SECAO).pack(side="left")
        tk.Label(topo, text="Filtrar:", bg=COR_FUNDO, fg=COR_TEXTO_SUAVE).pack(side="left", padx=(18, 4))
        self.var_filtro = tk.StringVar()
        self.var_filtro.trace_add("write", lambda *_: self._filtrar())
        ttk.Entry(topo, textvariable=self.var_filtro, width=24).pack(side="left")
        botao_secundario(topo, "Atualizar lista", self.atualizar_lista).pack(side="right")

        colunas = ("id", "nome", "cpf", "telefone", "email", "data")
        self.tabela = ttk.Treeview(direita, columns=colunas, show="headings", selectmode="browse")
        titulos = {"id": "ID", "nome": "Nome", "cpf": "CPF", "telefone": "Telefone", "email": "Email", "data": "Cadastro"}
        larguras = {"id": 45, "nome": 190, "cpf": 110, "telefone": 100, "email": 170, "data": 95}
        for col in colunas:
            self.tabela.heading(col, text=titulos[col])
            self.tabela.column(col, width=larguras[col], anchor="w" if col in ("nome", "email") else "center")
        self.tabela.grid(row=1, column=0, sticky="nsew")
        barra = ttk.Scrollbar(direita, orient="vertical", command=self.tabela.yview)
        self.tabela.configure(yscrollcommand=barra.set)
        barra.grid(row=1, column=1, sticky="ns")
        self.tabela.bind("<<TreeviewSelect>>", self._selecionar)

    def _campo(self, card, linha, rotulo, variavel) -> ttk.Entry:
        tk.Label(card, text=rotulo, bg=COR_CARD, fg=COR_TEXTO_SUAVE, font=FONTE_BASE).grid(
            row=linha, column=0, sticky="w", padx=(18, 10), pady=6
        )
        entrada = ttk.Entry(card, textvariable=variavel, width=26)
        entrada.grid(row=linha, column=1, sticky="ew", padx=(0, 18), pady=6)
        return entrada

    def _limpar(self) -> None:
        self.id_selecionado = None
        self.var_nome.set("")
        self.var_cpf.set("")
        self.var_telefone.set("")
        self.var_email.set("")
        for item in self.tabela.selection():
            self.tabela.selection_remove(item)

    def _selecionar(self, event=None) -> None:
        selecionado = self.tabela.selection()
        if not selecionado:
            return
        valores = self.tabela.item(selecionado[0], "values")
        self.id_selecionado = int(valores[0])
        self.var_nome.set(valores[1])
        self.var_cpf.set(valores[2])
        self.var_telefone.set("" if valores[3] == "-" else valores[3])
        self.var_email.set("" if valores[4] == "-" else valores[4])

    def _salvar(self) -> None:
        try:
            if self.id_selecionado is None:
                cliente = self.servico.cadastrar_cliente(
                    self.var_nome.get(), self.var_cpf.get(), self.var_telefone.get(), self.var_email.get()
                )
                messagebox.showinfo("Sucesso", f"Cliente '{cliente.nome}' cadastrado com o ID {cliente.id}.")
            else:
                ok = self.servico.atualizar_cliente(
                    self.id_selecionado, self.var_nome.get(), self.var_cpf.get(), self.var_telefone.get(), self.var_email.get()
                )
                if ok:
                    messagebox.showinfo("Sucesso", "Cliente atualizado com sucesso.")
                else:
                    messagebox.showwarning("Aviso", "Nenhum cliente foi atualizado. Verifique o ID.")
        except Exception as erro:
            _tratar_erro_servico(erro)
            return

        self._limpar()
        self.atualizar_lista()

    def _remover(self) -> None:
        if self.id_selecionado is None:
            messagebox.showwarning("Aviso", "Selecione um cliente na lista para remover.")
            return
        if not messagebox.askyesno("Confirmar remocao", "Tem certeza que deseja remover este cliente?"):
            return
        try:
            ok = self.servico.remover_cliente(self.id_selecionado)
            if ok:
                messagebox.showinfo("Sucesso", "Cliente removido com sucesso.")
            else:
                messagebox.showwarning("Aviso", "Nenhum cliente foi removido.")
        except Exception as erro:
            _tratar_erro_servico(
                erro,
                contexto_integridade="Este cliente nao pode ser removido porque ja possui vendas associadas.",
            )
            return
        self._limpar()
        self.atualizar_lista()

    def atualizar_lista(self) -> None:
        self._todos = self.servico.listar_clientes()
        self._preencher(self._todos)

    def _filtrar(self) -> None:
        termo = self.var_filtro.get().strip().lower()
        if not termo:
            self._preencher(self._todos)
            return
        filtrados = [c for c in self._todos if termo in c.nome.lower() or termo in (c.cpf or "")]
        self._preencher(filtrados)

    def _preencher(self, clientes) -> None:
        self.tabela.delete(*self.tabela.get_children())
        for c in clientes:
            self.tabela.insert(
                "", "end",
                values=(c.id, c.nome, c.cpf, c.telefone or "-", c.email or "-", c.data_cadastro),
            )


# ---------------------------------------------------------------------------
# Aba de Vendas
# ---------------------------------------------------------------------------
class AbaVendas(tk.Frame):
    def __init__(
        self,
        master: tk.Widget,
        servico_venda: VendaService,
        servico_produto: ProdutoService,
        servico_cliente: ClienteService,
        app: "AplicacaoPrincipal",
    ) -> None:
        super().__init__(master, bg=COR_FUNDO)
        self.servico_venda = servico_venda
        self.servico_produto = servico_produto
        self.servico_cliente = servico_cliente
        self.app = app
        self.carrinho: list[dict] = []
        self.mapa_produtos: dict = {}
        self.mapa_clientes: dict = {}
        self._montar_layout()
        self.atualizar_combos()
        self.atualizar_lista_vendas()

    def _montar_layout(self) -> None:
        topo = tk.Frame(self, bg=COR_CARD, highlightbackground=COR_BORDA, highlightthickness=1)
        topo.pack(fill="x", padx=6, pady=(6, 10))

        tk.Label(topo, text="Registrar nova venda", bg=COR_CARD, font=FONTE_SECAO, fg=COR_TEXTO).grid(
            row=0, column=0, columnspan=7, sticky="w", padx=18, pady=(14, 10)
        )

        tk.Label(topo, text="Cliente:", bg=COR_CARD, fg=COR_TEXTO_SUAVE).grid(row=1, column=0, sticky="w", padx=(18, 4))
        self.combo_cliente = ttk.Combobox(topo, state="readonly", width=28)
        self.combo_cliente.grid(row=1, column=1, sticky="w", padx=(0, 18))

        tk.Label(topo, text="Produto:", bg=COR_CARD, fg=COR_TEXTO_SUAVE).grid(row=1, column=2, sticky="w", padx=(0, 4))
        self.combo_produto = ttk.Combobox(topo, state="readonly", width=34)
        self.combo_produto.grid(row=1, column=3, sticky="w", padx=(0, 18))

        tk.Label(topo, text="Qtd:", bg=COR_CARD, fg=COR_TEXTO_SUAVE).grid(row=1, column=4, sticky="w")
        self.var_quantidade = tk.StringVar(value="1")
        tk.Spinbox(topo, from_=1, to=99999, textvariable=self.var_quantidade, width=6).grid(
            row=1, column=5, sticky="w", padx=(4, 12)
        )

        botao_primario(topo, "Adicionar item", self._adicionar_item).grid(row=1, column=6, padx=(0, 18), pady=(0, 14))

        meio = tk.Frame(self, bg=COR_FUNDO)
        meio.pack(fill="both", expand=False, padx=6, pady=(0, 10))

        colunas = ("produto", "quantidade", "preco_unit", "subtotal")
        self.tabela_carrinho = ttk.Treeview(meio, columns=colunas, show="headings", height=5, selectmode="browse")
        titulos = {"produto": "Produto", "quantidade": "Quantidade", "preco_unit": "Preco unit. (R$)", "subtotal": "Subtotal (R$)"}
        for col in colunas:
            self.tabela_carrinho.heading(col, text=titulos[col])
            self.tabela_carrinho.column(col, anchor="w" if col == "produto" else "center", width=220 if col == "produto" else 150)
        self.tabela_carrinho.pack(side="left", fill="both", expand=True)

        lateral = tk.Frame(meio, bg=COR_FUNDO)
        lateral.pack(side="left", fill="y", padx=(12, 0))
        botao_perigo(lateral, "Remover item", self._remover_item).pack(fill="x", pady=(0, 10))
        self.label_total = tk.Label(lateral, text="Total: R$ 0,00", bg=COR_FUNDO, font=FONTE_SECAO, fg=COR_TEXTO)
        self.label_total.pack(fill="x", pady=(0, 10))
        botao_primario(lateral, "Finalizar venda", self._finalizar_venda).pack(fill="x")

        baixo = tk.Frame(self, bg=COR_FUNDO)
        baixo.pack(fill="both", expand=True, padx=6, pady=(4, 6))

        cabecalho_baixo = tk.Frame(baixo, bg=COR_FUNDO)
        cabecalho_baixo.pack(fill="x")
        tk.Label(cabecalho_baixo, text="Vendas registradas", bg=COR_FUNDO, font=FONTE_SECAO, fg=COR_TEXTO).pack(side="left")
        botao_secundario(cabecalho_baixo, "Atualizar", self.atualizar_lista_vendas).pack(side="right")
        botao_perigo(cabecalho_baixo, "Remover venda", self._remover_venda).pack(side="right", padx=(0, 8))
        botao_secundario(cabecalho_baixo, "Ver itens", self._ver_itens).pack(side="right", padx=(0, 8))

        colunas_v = ("id", "cliente", "data", "total")
        self.tabela_vendas = ttk.Treeview(baixo, columns=colunas_v, show="headings")
        titulos_v = {"id": "ID", "cliente": "Cliente", "data": "Data", "total": "Total (R$)"}
        larguras_v = {"id": 55, "cliente": 260, "data": 170, "total": 110}
        for col in colunas_v:
            self.tabela_vendas.heading(col, text=titulos_v[col])
            self.tabela_vendas.column(col, width=larguras_v[col], anchor="w" if col == "cliente" else "center")
        self.tabela_vendas.pack(fill="both", expand=True, pady=(8, 0))

    def atualizar_combos(self) -> None:
        selecao_produto_atual = self.combo_produto.get()
        selecao_cliente_atual = self.combo_cliente.get()

        produtos = self.servico_produto.listar_produtos()
        self.mapa_produtos = {
            f"{p.nome} - R$ {p.preco:.2f} (estoque: {p.estoque})": p for p in produtos
        }
        self.combo_produto["values"] = list(self.mapa_produtos.keys())
        if selecao_produto_atual in self.mapa_produtos:
            self.combo_produto.set(selecao_produto_atual)
        elif self.mapa_produtos:
            self.combo_produto.current(0)
        else:
            self.combo_produto.set("")

        clientes = self.servico_cliente.listar_clientes()
        self.mapa_clientes = {"Sem cliente identificado": None}
        self.mapa_clientes.update({f"{c.nome} (CPF {c.cpf})": c.id for c in clientes})
        self.combo_cliente["values"] = list(self.mapa_clientes.keys())
        if selecao_cliente_atual in self.mapa_clientes:
            self.combo_cliente.set(selecao_cliente_atual)
        else:
            self.combo_cliente.current(0)

    def _adicionar_item(self) -> None:
        chave_produto = self.combo_produto.get()
        if not chave_produto or chave_produto not in self.mapa_produtos:
            messagebox.showwarning("Aviso", "Selecione um produto.")
            return
        try:
            quantidade = int(self.var_quantidade.get())
            if quantidade <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Dados invalidos", "Quantidade deve ser um numero inteiro maior que zero.")
            return

        produto = self.mapa_produtos[chave_produto]

        for item in self.carrinho:
            if item["id_produto"] == produto.id:
                item["quantidade"] += quantidade
                break
        else:
            self.carrinho.append(
                {"id_produto": produto.id, "nome": produto.nome, "quantidade": quantidade, "preco_unit": produto.preco}
            )
        self._redesenhar_carrinho()

    def _remover_item(self) -> None:
        selecionado = self.tabela_carrinho.selection()
        if not selecionado:
            messagebox.showwarning("Aviso", "Selecione um item do carrinho para remover.")
            return
        indice = self.tabela_carrinho.index(selecionado[0])
        del self.carrinho[indice]
        self._redesenhar_carrinho()

    def _redesenhar_carrinho(self) -> None:
        self.tabela_carrinho.delete(*self.tabela_carrinho.get_children())
        total = 0.0
        for item in self.carrinho:
            subtotal = item["quantidade"] * item["preco_unit"]
            total += subtotal
            self.tabela_carrinho.insert(
                "", "end",
                values=(item["nome"], item["quantidade"], f"{item['preco_unit']:.2f}", f"{subtotal:.2f}"),
            )
        self.label_total.config(text=f"Total: R$ {total:.2f}")

    def _finalizar_venda(self) -> None:
        if not self.carrinho:
            messagebox.showwarning("Aviso", "Adicione ao menos um item antes de finalizar a venda.")
            return

        chave_cliente = self.combo_cliente.get()
        id_cliente = self.mapa_clientes.get(chave_cliente)
        itens = [{"id_produto": item["id_produto"], "quantidade": item["quantidade"]} for item in self.carrinho]

        try:
            venda = self.servico_venda.registrar_venda(itens, id_cliente)
        except Exception as erro:
            _tratar_erro_servico(erro)
            return

        messagebox.showinfo("Venda registrada", f"Venda #{venda.id_venda} registrada com sucesso!\nTotal: R$ {venda.total:.2f}")
        self.carrinho.clear()
        self._redesenhar_carrinho()
        self.atualizar_combos()
        self.atualizar_lista_vendas()
        self.app.aba_produtos.atualizar_lista()

    def atualizar_lista_vendas(self) -> None:
        vendas = self.servico_venda.listar_vendas()
        clientes = {c.id: c.nome for c in self.servico_cliente.listar_clientes()}
        self.tabela_vendas.delete(*self.tabela_vendas.get_children())
        for v in vendas:
            nome_cliente = clientes.get(v.id_cliente, "Sem cliente") if v.id_cliente else "Sem cliente"
            self.tabela_vendas.insert("", "end", values=(v.id_venda, nome_cliente, v.data_venda, f"{v.total:.2f}"))

    def _venda_selecionada_id(self) -> Optional[int]:
        selecionado = self.tabela_vendas.selection()
        if not selecionado:
            return None
        valores = self.tabela_vendas.item(selecionado[0], "values")
        return int(valores[0])

    def _ver_itens(self) -> None:
        id_venda = self._venda_selecionada_id()
        if id_venda is None:
            messagebox.showwarning("Aviso", "Selecione uma venda na lista.")
            return
        try:
            itens = self.servico_venda.listar_itens_da_venda(id_venda)
        except Exception as erro:
            _tratar_erro_servico(erro)
            return

        produtos = {p.id: p.nome for p in self.servico_produto.listar_produtos()}

        janela = tk.Toplevel(self)
        janela.title(f"Itens da venda #{id_venda}")
        janela.geometry("500x340")
        janela.configure(bg=COR_FUNDO)
        janela.transient(self.winfo_toplevel())

        tk.Label(janela, text=f"Itens da venda #{id_venda}", bg=COR_FUNDO, font=FONTE_SECAO, fg=COR_TEXTO).pack(
            anchor="w", padx=18, pady=(18, 10)
        )

        colunas = ("produto", "quantidade", "preco_unit", "subtotal")
        tabela = ttk.Treeview(janela, columns=colunas, show="headings")
        titulos = {"produto": "Produto", "quantidade": "Qtd", "preco_unit": "Preco unit. (R$)", "subtotal": "Subtotal (R$)"}
        for col in colunas:
            tabela.heading(col, text=titulos[col])
            tabela.column(col, anchor="w" if col == "produto" else "center")
        tabela.pack(fill="both", expand=True, padx=18, pady=(0, 18))

        if not itens:
            tk.Label(janela, text="Esta venda nao possui itens.", bg=COR_FUNDO, fg=COR_TEXTO_SUAVE).pack()
        for item in itens:
            nome_produto = produtos.get(item.id_produto, f"Produto #{item.id_produto}")
            subtotal = item.quantidade * item.preco_unit
            tabela.insert("", "end", values=(nome_produto, item.quantidade, f"{item.preco_unit:.2f}", f"{subtotal:.2f}"))

    def _remover_venda(self) -> None:
        id_venda = self._venda_selecionada_id()
        if id_venda is None:
            messagebox.showwarning("Aviso", "Selecione uma venda na lista para remover.")
            return
        if not messagebox.askyesno("Confirmar remocao", f"Remover a venda #{id_venda}? Esta acao nao pode ser desfeita."):
            return
        try:
            ok = self.servico_venda.remover_venda(id_venda)
            if ok:
                messagebox.showinfo("Sucesso", "Venda removida com sucesso.")
            else:
                messagebox.showwarning("Aviso", "Nenhuma venda foi removida.")
        except Exception as erro:
            _tratar_erro_servico(
                erro,
                contexto_integridade="Esta venda nao pode ser removida porque ainda possui itens vinculados a ela.",
            )
            return
        self.atualizar_lista_vendas()


# ---------------------------------------------------------------------------
# Janela principal
# ---------------------------------------------------------------------------
class AplicacaoPrincipal(tk.Tk):
    def __init__(self, servicos: dict, configuracao: dict) -> None:
        super().__init__()
        self.servicos = servicos
        self.configuracao = configuracao

        self.title("Sistema de Conveniencia - Produtos, Clientes e Vendas")
        self.geometry("1180x700")
        self.minsize(1020, 620)
        self.configure(bg=COR_FUNDO)

        self._configurar_estilo()
        self._montar_cabecalho()
        self._montar_notebook()
        self._montar_rodape()

    def _configurar_estilo(self) -> None:
        estilo = ttk.Style(self)
        try:
            estilo.theme_use("clam")
        except tk.TclError:
            pass

        estilo.configure("TNotebook", background=COR_FUNDO, borderwidth=0)
        estilo.configure(
            "TNotebook.Tab",
            font=FONTE_SECAO,
            padding=(18, 10),
            background=COR_SECUNDARIO,
            foreground=COR_TEXTO_SUAVE,
        )
        estilo.map(
            "TNotebook.Tab",
            background=[("selected", COR_CARD)],
            foreground=[("selected", COR_ACCENT)],
        )

        estilo.configure(
            "Treeview",
            font=FONTE_BASE,
            rowheight=26,
            background=COR_CARD,
            fieldbackground=COR_CARD,
            foreground=COR_TEXTO,
            borderwidth=0,
        )
        estilo.configure("Treeview.Heading", font=FONTE_SECAO, background=COR_SECUNDARIO, foreground=COR_TEXTO)
        estilo.map("Treeview", background=[("selected", COR_ACCENT)], foreground=[("selected", "white")])

        estilo.configure("TEntry", padding=5)
        estilo.configure("TCombobox", padding=5)

    def _montar_cabecalho(self) -> None:
        barra = tk.Frame(self, bg=COR_BARRA, height=68)
        barra.pack(fill="x", side="top")
        barra.pack_propagate(False)

        tk.Label(
            barra, text="Conveniencia do Posto", bg=COR_BARRA, fg=COR_BARRA_TEXTO, font=FONTE_TITULO,
        ).pack(side="left", padx=(24, 10), pady=10)
        tk.Label(
            barra, text="Produtos  -  Clientes  -  Vendas", bg=COR_BARRA, fg=COR_BARRA_SUBTEXTO, font=FONTE_SUBTITULO,
        ).pack(side="left")

    def _montar_notebook(self) -> None:
        container = tk.Frame(self, bg=COR_FUNDO)
        container.pack(fill="both", expand=True, padx=14, pady=14)

        self.notebook = ttk.Notebook(container)
        self.notebook.pack(fill="both", expand=True)

        self.aba_produtos = AbaProdutos(self.notebook, self.servicos["produto"])
        self.aba_clientes = AbaClientes(self.notebook, self.servicos["cliente"])
        self.aba_vendas = AbaVendas(
            self.notebook, self.servicos["venda"], self.servicos["produto"], self.servicos["cliente"], self
        )

        self.notebook.add(self.aba_produtos, text="  Produtos  ")
        self.notebook.add(self.aba_clientes, text="  Clientes  ")
        self.notebook.add(self.aba_vendas, text="  Vendas  ")

        self.notebook.bind("<<NotebookTabChanged>>", self._ao_trocar_aba)

    def _ao_trocar_aba(self, event=None) -> None:
        aba_atual = self.notebook.select()
        if not aba_atual:
            return
        widget = self.nametowidget(aba_atual)
        if widget is self.aba_vendas:
            self.aba_vendas.atualizar_combos()
        elif widget is self.aba_produtos:
            self.aba_produtos.atualizar_lista()
        elif widget is self.aba_clientes:
            self.aba_clientes.atualizar_lista()

    def _montar_rodape(self) -> None:
        rodape = tk.Frame(self, bg=COR_SECUNDARIO, height=26)
        rodape.pack(fill="x", side="bottom")
        rodape.pack_propagate(False)

        texto = (
            f"Conectado ao MySQL em {self.configuracao['host']}:{self.configuracao['porta']} "
            f"| banco '{self.configuracao['banco']}' | usuario '{self.configuracao['usuario']}'"
        )
        tk.Label(rodape, text=texto, bg=COR_SECUNDARIO, fg=COR_TEXTO_SUAVE, font=FONTE_RODAPE).pack(side="left", padx=12)


# ---------------------------------------------------------------------------
# Ponto de entrada da interface
# ---------------------------------------------------------------------------
def iniciar_aplicacao() -> None:
    from src.apresentacao.fabrica_servicos import criar_servicos
    from src.config.configuracao_banco import obter_configuracao_banco
    from src.dados.conexao_singleton import ConexaoSingleton

    configuracao = obter_configuracao_banco()

    try:
        servicos = criar_servicos()
    except Exception as erro:
        _mostrar_erro_conexao(configuracao, erro)
        return

    app = AplicacaoPrincipal(servicos, configuracao)
    try:
        app.mainloop()
    finally:
        ConexaoSingleton.fechar_conexao()


def _mostrar_erro_conexao(configuracao: dict, erro: Exception) -> None:
    raiz = tk.Tk()
    raiz.withdraw()
    messagebox.showerror(
        "Nao foi possivel conectar ao MySQL",
        "Nao foi possivel conectar ao banco de dados MySQL.\n\n"
        f"Host: {configuracao['host']}:{configuracao['porta']}\n"
        f"Banco: {configuracao['banco']}\n"
        f"Usuario: {configuracao['usuario']}\n\n"
        "Verifique se o container do MySQL esta no ar. A partir da raiz do "
        "projeto, rode:\n\n"
        "    docker compose up -d\n\n"
        f"Detalhes tecnicos: {erro}",
    )
    raiz.destroy()
